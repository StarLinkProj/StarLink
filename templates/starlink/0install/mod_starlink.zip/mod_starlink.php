/* common files for starlink templates */
<?php
defined( '_JEXEC' ) or die;