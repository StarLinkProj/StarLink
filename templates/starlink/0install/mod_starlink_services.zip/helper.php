<?php
/**
 * Helper class for Starlink_Services_Block module
 *
 */

class ModStarlinkServicesHelper {

  //public static function getTitle($params) {
    // return ('IT-услуги для бизнеса, работающего без остановки');
    // return $module->title;
  //}
}